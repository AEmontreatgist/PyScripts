I have submitted 2 files aside from this README.txt each with diffrent things in them

AEBreakfastMakerNoInputInt.py is fully functioning, but lacks the use of the inputInt() command, and instead 
asks if the user would like eggs, and then limits them btween 1-3 eggs becase of a supply chain shortage

AEBrakfastMakerInputInt.py is almost funcioning, it has inputInt() in the code howerver I can not get it to 
add it to the total cost of the order, howerver eveything else is functioning correctly.

both of them have spelling mistakes in it, however it is likely minor typos or a extra letter.

I am sorry that it is not working commpletly but it should show how it is idealy supposed to work and 
demonstrates my knowlge, I just cant get inputInt() to appened for some reason.

The bug is that it cant mulltiply the dictonary value for egg by cheeseChoice which would add the total cost to 
it, its just a anoying error that would require significat work to fix that i was not anticipating
